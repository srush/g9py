import random
from .operators import prod
from numpy import array, float64, ndarray
import numpy
import numpy as np
try:
    import numba

    HAS_NUMBA = True
except ImportError:
    HAS_NUMBA = False
MAX_DIMS = 32


class IndexingError(RuntimeError):
    "Exception raised for indexing errors."
    pass


def index_to_position(index, strides):
    """
    Converts a multidimensional tensor `index` into a single-dimensional position in
    storage based on strides.

    Args:
        index (array-like): index tuple of ints
        strides (array-like): tensor strides

    Returns:
        int : position in storage
    """

    # ASSIGN2.1
    position = 0
    for ind, stride in zip(index, strides):
        position += ind * stride
    return position
    # END ASSIGN2.1


def to_index(ordinal, shape, out_index):
    """
    Convert an `ordinal` to an index in the `shape`.
    Should ensure that enumerating position 0 ... size of a
    tensor produces every index exactly once. It
    may not be the inverse of `index_to_position`.

    Args:
        ordinal (int): ordinal position to convert.
        shape (tuple): tensor shape.
        out_index (array): the index corresponding to position.

    Returns:
      None : Fills in `out_index`.

    """
    # ASSIGN2.1
    cur_ord = ordinal + 0
    for i in range(len(shape) - 1, -1, -1):
        sh = shape[i]
        out_index[i] = int(cur_ord % sh)
        cur_ord = cur_ord // sh
    # END ASSIGN2.1


def broadcast_index(big_index, big_shape, shape, out_index):
    """
    Convert a `big_index` into `big_shape` to a smaller `out_index`
    into `shape` following broadcasting rules. In this case
    it may be larger or with more dimensions than the `shape`
    given. Additional dimensions may need to be mapped to 0 or
    removed.

    Args:
        big_index (array-like): multidimensional index of bigger tensor
        big_shape (array-like): tensor shape of bigger tensor
        shape (array-like): tensor shape of smaller tensor
        out_index (array-like): multidimensional index of smaller tensor

    Returns:
        None : Fills in `out_index`.
    """
    # ASSIGN2.2
    for i, s in enumerate(shape):
        if s > 1:
            out_index[i] = big_index[i + (len(big_shape) - len(shape))]
        else:
            out_index[i] = 0
    return None
    # END ASSIGN2.2


def shape_broadcast(shape1, shape2):
    """
    Broadcast two shapes to create a new union shape.

    Args:
        shape1 (tuple) : first shape
        shape2 (tuple) : second shape

    Returns:
        tuple : broadcasted shape

    Raises:
        IndexingError : if cannot broadcast
    """
    # ASSIGN2.2
    a, b = shape1, shape2
    m = max(len(a), len(b))
    c_rev = [0] * m
    a_rev = list(reversed(a))
    b_rev = list(reversed(b))
    for i in range(m):
        if i >= len(a):
            c_rev[i] = b_rev[i]
        elif i >= len(b):
            c_rev[i] = a_rev[i]
        else:
            c_rev[i] = max(a_rev[i], b_rev[i])
            if a_rev[i] != c_rev[i] and a_rev[i] != 1:
                raise IndexingError(f"Broadcast failure {a} {b}")
            if b_rev[i] != c_rev[i] and b_rev[i] != 1:
                raise IndexingError(f"Broadcast failure {a} {b}")
    return tuple(reversed(c_rev))
    # END ASSIGN2.2


def strides_from_shape(shape):
    layout = [1]
    offset = 1
    for s in reversed(shape):
        layout.append(s * offset)
        offset = s * offset
    return tuple(reversed(layout[:-1]))


def mtuple(x):
    if isinstance(x, int):
        return x
    else:
        return tuple(x)

class TensorData:
    def __init__(self, storage, shape, strides=None):
        # self.storage = storage.view(shape)
        if isinstance(storage, list):
            self._storage = np.array(storage, dtype=np.float64)
        else:
            self._storage = storage
            
        if shape is not None:
            self._storage = self._storage.reshape(shape)
        if strides is not None:
            self._storage = numpy.lib.stride_tricks.as_strided(
                storage, shape=shape, strides=[s * 8 for s in strides]
            )
        self.shape = self._storage.shape
        # if isinstance(storage, ndarray):
        #     self._storage = storage
        # else:
        #     self._storage = array(storage, dtype=float64)

        # if strides is None:
        #     strides = strides_from_shape(shape)

        # assert isinstance(strides, tuple), "Strides must be tuple"
        # assert isinstance(shape, tuple), "Shape must be tuple"
        # if len(strides) != len(shape):
        #     raise IndexingError(f"Len of strides {strides} must match {shape}.")
        # self._strides = array(strides)
        # self._shape = array(shape)
        # self.strides = strides
        # self.dims = len(strides)
        # self.size = int(prod(shape))
        # self.shape = shape
        # assert len(self._storage) == self.size


        
    def to_cuda_(self):  # pragma: no cover
        if not HAS_NUMBA:
            raise NotImplementedError("No Numba GPU backend")
        if not numba.cuda.is_cuda_array(self._storage):
            self._storage = numba.cuda.to_device(self._storage)

    def is_contiguous(self):
        """
        Check that the layout is contiguous, i.e. outer dimensions have bigger strides than inner dimensions.

        Returns:
            bool : True if contiguous
        """
        # return self._storage.contiguous
        last = 1e9
        for stride in self.strides:
            if stride > last:
                return False
            last = stride
        return True

        
    @staticmethod
    def shape_broadcast(shape_a, shape_b):
        return shape_broadcast(shape_a, shape_b)

    def index(self, index):
        return self._storage[mtuple(index)]
        # if isinstance(index, int):
        #     index = array([index])
        # if isinstance(index, tuple):
        #     index = array(index)

        # # Check for errors
        # if index.shape[0] != len(self.shape):
        #     raise IndexingError(f"Index {index} must be size of {self.shape}.")
        # for i, ind in enumerate(index):
        #     if ind >= self.shape[i]:
        #         raise IndexingError(f"Index {index} out of range {self.shape}.")
        #     if ind < 0:
        #         raise IndexingError(f"Negative indexing for {index} not supported.")

        # # Call fast indexing.
        # return index_to_position(array(index), self._strides)

    @property
    def size(self):
        p = 1
        for i in range(len(self.shape)):
            p *= self.shape[i]
        return p
    
    @property
    def strides(self):
        return [s // 8 for s in self._storage.strides]

    # @property
    # def contiguous(self):
    #     return [s // 8 for s in self._storage.strides]

    @property
    def dims(self):
        return len(self.shape)
        
    def indices(self):
        lshape = array(self.shape)
        out_index = array(self.shape)
        for i in range(self.size):
            to_index(i, lshape, out_index)
            yield tuple(out_index)

    def sample(self):
        return tuple((random.randint(0, s - 1) for s in self.shape))

    def get(self, key):
        return self._storage[mtuple(key)]

    def set(self, key, val):
        self._storage[mtuple(key)] = val

    def tuple(self):
        return (self._storage, self.shape, [s // 8 for s in self._storage.strides])

    def permute(self, *order):
        """
        Permute the dimensions of the tensor.

        Args:
            order (list): a permutation of the dimensions

        Returns:
            :class:`TensorData`: a new TensorData with the same storage and a new dimension order.
        """
        assert list(sorted(order)) == list(
            range(len(self.shape))
        ), f"Must give a position to each dimension. Shape: {self.shape} Order: {order}"

        # assert False
        # ASSIGN2.1
        return TensorData(
            self._storage.transpose(*order), None)
        
        # END ASSIGN2.1

    def to_string(self):
        return str(self._storage)
